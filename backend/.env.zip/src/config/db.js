const mysql = require('mysql2/promise')

const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  port: process.env.DB_PORT || 3306,
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'a1construction',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
  timezone: '+05:30'
})

pool.getConnection()
  .then(conn => { console.log('✅ MySQL connected'); conn.release() })
  .catch(err => { console.error('❌ MySQL connection failed:', err.message) })

module.exports = pool
